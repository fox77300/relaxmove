
import React from 'react'
import ReactDOM from 'react-dom/client'
import RelaxationExperience from './RelaxationExperience'
import './index.css'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <RelaxationExperience />
  </React.StrictMode>,
)
